# CopadoTrails
Repository used to share code snippets required during the Copado Trail process
